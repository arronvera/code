package com.vera.musicplayer_2.adapter;

import java.util.ArrayList;
import java.util.List;

import com.vera.musicplayer_2.R;
import com.vera.musicplayer_2.R.id;
import com.vera.musicplayer_2.R.layout;
import com.vera.musicplayer_2.entity.Music;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

/**
 * ������ʾListView��Adapter
 * 
 * @author vera
 * @version 2.0
 */
public class MusicAdapter extends BaseAdapter {
	private Context context;
	private List<Music> musics;
	private TextView tvName;
	private TextView tvPath;

	/**
	 * ���췽��
	 * 
	 * @param context�����Ķ���
	 * @param musics���������ݵ�list����
	 * 
	 */
	public MusicAdapter(Context context, List<Music> musics) {
		this.context = context;
		this.musics = musics;
	}

	@Override
	public int getCount() {
		return musics.size();
	}

	@Override
	public View getView(int position, View convertView, ViewGroup arg2) {

		Music music = musics.get(position);
		if (convertView == null) {// ���ģ��Ϊ�����½�
			LayoutInflater inflater = LayoutInflater.from(context);
			convertView = inflater.inflate(R.layout.music_item, null);
			tvName = (TextView) convertView.findViewById(R.id.tv_name);
			tvPath = (TextView) convertView.findViewById(R.id.tv_path);
		}
		tvName.setText(music.getName());
		tvPath.setText(music.getPath());
		return convertView;
	}

	@Override
	public Object getItem(int arg0) {
		return null;
	}

	@Override
	public long getItemId(int arg0) {
		return 0;
	}
}
