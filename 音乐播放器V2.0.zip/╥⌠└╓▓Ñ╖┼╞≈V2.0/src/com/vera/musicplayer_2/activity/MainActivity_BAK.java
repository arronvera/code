package com.vera.musicplayer_2.activity;

import java.util.List;

import com.vera.musicplayer_2.R;
import com.vera.musicplayer_2.R.id;
import com.vera.musicplayer_2.R.layout;
import com.vera.musicplayer_2.adapter.MusicAdapter;
import com.vera.musicplayer_2.app.MusicPlayerApplication;
import com.vera.musicplayer_2.entity.Music;
import com.vera.musicplayer_2.service.PlayMusicService;
import com.vera.musicplayer_2.util.Consts;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity_BAK extends Activity implements View.OnClickListener,
		OnItemClickListener, Consts {
	/**
	 * �����б�
	 */
	private ListView lvMusicItem;
	/**
	 * ��ť���Ż���ͣ
	 */
	private ImageButton ibPlayOrPause;
	/**
	 * ��ť��һ��
	 */
	private ImageButton ibPrevious;
	/**
	 * ��ť��һ��
	 */
	private ImageButton ibNext;
	/**
	 * ������ֵļ���
	 */
	private List<Music> musics;
	/**
	 * ������
	 */
	private MusicAdapter adapter;
	/**
	 * �Ƿ��ڲ���
	 */
	private boolean isPlaying;
	/**
	 * ����������ʾ
	 */
	// private TextView tvName;
	private MusicPlayerApplication app;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		// ��ʼ��
		lvMusicItem = (ListView) findViewById(R.id.lv_music_item);
		ibPlayOrPause = (ImageButton) findViewById(R.id.ib_play_or_pause);
		ibPrevious = (ImageButton) findViewById(R.id.ib_previous);
		ibNext = (ImageButton) findViewById(R.id.ib_next);
		// tvName = (TextView) findViewById(R.id.tv_musicname);
		// ͨ��Application��ȡ����,ǧ����ʹ��new��ȡApplication
		app = (MusicPlayerApplication) getApplication();
		musics = app.getMusics();
		// ������
		adapter = new MusicAdapter(this, musics);
		lvMusicItem.setAdapter(adapter);

		// Ϊ��ť���ü�����
		ibPlayOrPause.setOnClickListener(this);
		ibPrevious.setOnClickListener(this);
		ibNext.setOnClickListener(this);
		lvMusicItem.setOnItemClickListener(this);
	}

	@Override
	public void onClick(View v) {
		Intent intent = new Intent(MainActivity_BAK.this, PlayMusicService.class);
		switch (v.getId()) {
		case R.id.ib_play_or_pause:
			// ���Ż���ͣ
			intent.putExtra(COMMAND_STRING, COMMAND_PLAY_OR_PAUSE);
			startService(intent);
			isPlaying = !isPlaying;
			// �Ƿ񲥷�
			if (isPlaying) {
				ibPlayOrPause
						.setImageResource(android.R.drawable.ic_media_pause);
			} else {

				ibPlayOrPause
						.setImageResource(android.R.drawable.ic_media_play);
			}
			break;
		case R.id.ib_previous:
			intent.putExtra(COMMAND_STRING, COMMAND_PLAY_PREVIOUS);
			startService(intent);
			break;
		case R.id.ib_next:
			intent.putExtra(COMMAND_STRING, COMMAND_PLAY_NEXT);
			startService(intent);
			break;
		}
	}

	// �б����
	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int position,
			long arg3) {
		Intent intent = new Intent(MainActivity_BAK.this, PlayMusicService.class);
		intent.putExtra(COMMAND_STRING, COMMAND_PLAY_CLICK_ITEM);
		// �ѵ��λ�ô���ȥ
		intent.putExtra("position", position);
		startService(intent);
		isPlaying = true;
		// ͼƬ��Ϊ��ͣ
		ibPlayOrPause.setImageResource(android.R.drawable.ic_media_pause);

	}

}
