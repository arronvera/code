package com.vera.musicplayer_2.dal;

/**
 * ���ݹ�����
 * 
 * @author vera
 * 
 */
public class MusicDaoFactory {
	public static BaseDao newInstance() {
		return new MusicDao();

	}
}
