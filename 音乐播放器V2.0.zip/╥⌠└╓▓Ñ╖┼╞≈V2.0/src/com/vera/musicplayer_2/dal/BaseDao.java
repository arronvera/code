package com.vera.musicplayer_2.dal;

import java.util.List;

import com.vera.musicplayer_2.entity.Music;

public abstract class BaseDao {
	public abstract List<Music> setMusicData();
}
