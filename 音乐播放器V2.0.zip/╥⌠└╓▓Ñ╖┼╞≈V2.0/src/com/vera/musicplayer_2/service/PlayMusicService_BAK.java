package com.vera.musicplayer_2.service;

import java.io.IOException;
import java.util.List;

import com.vera.musicplayer_2.app.MusicPlayerApplication;
import com.vera.musicplayer_2.entity.Music;
import com.vera.musicplayer_2.util.Consts;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.widget.ImageButton;

public class PlayMusicService_BAK extends Service implements Consts {
	/**
	 * �������ֵĹ���
	 */
	private MediaPlayer player;
	private List<Music> musics;
	/**
	 * ��ͣλ��
	 */
	private int pausePosition;
	/**
	 * ����λ��
	 */
	private int musicPosition;
	private MusicPlayerApplication app;

	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}

	@Override
	public void onCreate() {
		player = new MediaPlayer();
		// ͨ��Application��ȡ����,ǧ����ʹ��new��ȡApplication
		app = (MusicPlayerApplication) getApplication();
		musics = app.getMusics();

	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		if (intent != null) {
			int command = intent.getIntExtra(COMMAND_STRING, 0);
			switch (command) {
			case COMMAND_PLAY_OR_PAUSE:// ���Ż���ͣ
				if (player.isPlaying()) {
					// ���ڲ��ţ���Ӧ����ͣ
					pause();
				} else {
					// û�в��ţ���Ӧ�ò���
					play(musicPosition);
				}
				break;
			case COMMAND_PLAY_PREVIOUS:// ��һ��
				previous();

				break;
			case COMMAND_PLAY_NEXT:// ��һ��
				next();
				break;

			case COMMAND_PLAY_CLICK_ITEM:// ���ŵ���б��еĸ���

				// ��ȡ���ŵ�λ��
				musicPosition = intent.getIntExtra("position", 0);
				play(musicPosition);
				break;
			}
		}

		return START_NOT_STICKY;
	}

	private void play(int position) {
		// �����ͣ
		pausePosition = 0;
		play();

	}

	private void next() {
		musicPosition++;
		if (musicPosition > musics.size() - 1) {
			musicPosition = 0;
		}
		pausePosition = 0;
		play(musicPosition);
	}

	private void previous() {
		musicPosition--;
		if (musicPosition < 0) {
			musicPosition = musics.size() - 1;
		}
		pausePosition = 0;
		play(musicPosition);
	}

	/**
	 * ��ͣ����
	 */
	private void pause() {
		player.pause();
		pausePosition = player.getCurrentPosition();

	}

	/**
	 * ���Ÿ���
	 */
	private void play() {
		try {
			player.reset();
			player.setDataSource(musics.get(musicPosition).getPath());
			player.prepare();
			player.seekTo(pausePosition);
			player.start();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
